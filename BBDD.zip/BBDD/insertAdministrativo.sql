INSERT INTO administrativo (run, nombre, apellido, correo, area, usuario_id)
VALUES
    ('12345678-9', 'Ana', 'Rodríguez', 'ana.rodriguez@example.com', 'Recursos Humanos', 1),
    ('98765432-1', 'Carlos', 'Gómez', 'carlos.gomez@example.com', 'Finanzas', 2),
    ('45678912-3', 'Laura', 'Fernández', 'laura.fernandez@example.com', 'Marketing', 3),
    ('32198765-4', 'Martín', 'Pérez', 'martin.perez@example.com', 'Ventas', 4),
    ('65432198-5', 'Valentina', 'Morales', 'valentina.morales@example.com', 'Operaciones', 5),
    ('78912345-6', 'Alejandro', 'Torres', 'alejandro.torres@example.com', 'Tecnología de la Información', 6),
    ('23456789-0', 'Sofía', 'Ramírez', 'sofia.ramirez@example.com', 'Compras', 7),
    ('56789012-3', 'Diego', 'Vargas', 'diego.vargas@example.com', 'Logística', 8),
    ('89012345-6', 'Isabella', 'Silva', 'isabella.silva@example.com', 'Servicio al Cliente', 9),
    ('98765432-1', 'Julián', 'Gutiérrez', 'julian.gutierrez@example.com', 'Administración General', 10),
    ('87654321-0', 'Gabriela', 'Ríos', 'gabriela.rios@example.com', 'Planificación Estratégica', 11),
    ('54321098-7', 'Andrés', 'Mendoza', 'andres.mendoza@example.com', 'Control de Calidad', 12),
    ('67890123-4', 'Natalia', 'Medina', 'natalia.medina@example.com', 'Desarrollo de Productos', 13),
    ('43210987-6', 'Sebastián', 'Herrera', 'sebastian.herrera@example.com', 'Relaciones Públicas', 14),
    ('78901234-5', 'Mariana', 'Castro', 'mariana.castro@example.com', 'Investigación y Desarrollo', 15),
    ('34567890-1', 'Daniel', 'Guzmán', 'daniel.guzman@example.com', 'Gestión de Proyectos', 16),
    ('23456789-0', 'Camila', 'Ortega', 'camila.ortega@example.com', 'Comunicación Corporativa', 17),
    ('56789012-3', 'Felipe', 'Paredes', 'felipe.paredes@example.com', 'Gestión de Recursos', 18),
    ('89012345-6', 'Victoria', 'Molina', 'victoria.molina@example.com', 'Legal y Cumplimiento', 19),
    ('98765432-1', 'Manuel', 'Valenzuela', 'manuel.valenzuela@example.com', 'Innovación y Creatividad', 20);

select * from administrativo;