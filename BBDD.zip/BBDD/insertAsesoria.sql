INSERT INTO asesoria (nombre, detalle, profesional_id, cliente_id)
VALUES
  ('Asesoría en Seguridad Laboral', 'Asesoría para mejorar las condiciones de seguridad en el lugar de trabajo.', 1, 1),
  ('Asesoría en Prevención de Riesgos', 'Asesoría para implementar medidas de prevención y reducción de riesgos.', 2, 2),
  ('Asesoría en Manejo de Sustancias Peligrosas', 'Asesoría para el manejo seguro de sustancias químicas en la empresa.', 3, 3),
  ('Asesoría en Protección contra Incendios', 'Asesoría para establecer protocolos de protección contra incendios.', 4, 4),
  ('Asesoría en Salud Ocupacional', 'Asesoría para mejorar la salud y bienestar de los trabajadores.', 5, 5),
  ('Asesoría en Seguridad Vial', 'Asesoría para promover la seguridad vial en la flota de vehículos de la empresa.', 6, 6),
  ('Asesoría en Manejo de Equipos de Protección Personal', 'Asesoría para el uso adecuado de equipos de protección personal.', 7, 7),
  ('Asesoría en Ergonomía Laboral', 'Asesoría para mejorar la ergonomía en los puestos de trabajo.', 8, 8),
  ('Asesoría en Higiene Industrial', 'Asesoría para evaluar y mejorar la higiene en el lugar de trabajo.', 9, 9),
  ('Asesoría en Gestión de Riesgos', 'Asesoría para implementar una gestión efectiva de riesgos laborales.', 10, 10),
  ('Asesoría en Prevención de Accidentes Laborales', 'Asesoría para reducir y prevenir accidentes en el entorno laboral.', 11, 11),
  ('Asesoría en Seguridad en Alturas', 'Asesoría para trabajar de manera segura en alturas y espacios confinados.', 12, 12),
  ('Asesoría en Seguridad Alimentaria', 'Asesoría para garantizar la seguridad y calidad de los alimentos.', 13, 13),
  ('Asesoría en Protección del Medio Ambiente', 'Asesoría para reducir el impacto ambiental de las operaciones.', 14, 14),
  ('Asesoría en Planes de Emergencia', 'Asesoría para desarrollar planes de emergencia y evacuación.', 15, 15),
  ('Asesoría en Uso Seguro de Maquinaria', 'Asesoría para el uso adecuado y seguro de maquinaria y equipos.', 16, 16),
  ('Asesoría en Prevención de Riesgos en la Construcción', 'Asesoría para prevenir riesgos en la industria de la construcción.', 17, 17),
  ('Asesoría en Seguridad Eléctrica', 'Asesoría para trabajar de manera segura con instalaciones eléctricas.', 18, 18),
  ('Asesoría en Prevención de Riesgos en Laboratorios', 'Asesoría para trabajar de manera segura en laboratorios.', 19, 19),
  ('Asesoría en Gestión de Residuos', 'Asesoría para una correcta gestión y disposición de residuos.', 20, 20);

select * from asesoria;