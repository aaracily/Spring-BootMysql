INSERT INTO capacitacion (nombre, detalle, fecha, hora, lugar, duracion, cantidad, cliente_id)
VALUES
  ('Introducción a la Prevención de Riesgos', 'Capacitación introductoria sobre los conceptos básicos de Prevención de Riesgos en el lugar de trabajo.', '2023-08-01', '09:00:00', 'Sala de Conferencias A', 2.5, 30, 1),
  ('Manejo Seguro de Sustancias Peligrosas', 'Capacitación enfocada en el correcto manejo y almacenamiento seguro de sustancias peligrosas.', '2023-08-05', '14:30:00', 'Salón de Eventos B', 1.5, 25, 2),
  ('Prevención de Accidentes Laborales', 'Capacitación para prevenir accidentes en el entorno laboral y promover una cultura de seguridad.', '2023-08-10', '10:00:00', 'Sala de Reuniones C', 3.0, 40, 3),
  ('Ergonomía y Postura Laboral', 'Capacitación sobre la importancia de una buena postura laboral para prevenir lesiones musculoesqueléticas.', '2023-08-15', '15:30:00', 'Salón de Conferencias D', 2.0, 20, 4),
  ('Prevención de Incendios', 'Capacitación para prevenir incendios y saber cómo actuar en caso de emergencia.', '2023-08-20', '11:00:00', 'Sala de Capacitación E', 2.5, 35, 5),
  ('Uso Seguro de Equipos y Maquinaria', 'Capacitación sobre el uso seguro de equipos y maquinaria en el lugar de trabajo.', '2023-08-25', '08:30:00', 'Salón de Eventos F', 1.0, 15, 6),
  ('Primeros Auxilios Básicos', 'Capacitación en primeros auxilios para actuar ante situaciones de emergencia.', '2023-08-30', '13:00:00', 'Sala de Reuniones G', 2.0, 25, 7),
  ('Seguridad en Alturas', 'Capacitación sobre las medidas de seguridad para trabajar en alturas y evitar riesgos.', '2023-09-05', '09:30:00', 'Salón de Conferencias H', 3.5, 40, 8),
  ('Gestión de Riesgos Laborales', 'Capacitación en la gestión efectiva de los riesgos laborales en la empresa.', '2023-09-10', '14:00:00', 'Sala de Capacitación I', 2.5, 30, 9),
  ('Prevención de Riesgos en Espacios Confinados', 'Capacitación para trabajar de manera segura en espacios confinados.', '2023-09-15', '10:30:00', 'Salón de Eventos J', 2.0, 20, 10),
  ('Manejo de Equipos de Protección Personal', 'Capacitación sobre la selección y uso adecuado de equipos de protección personal para reducir riesgos.', '2023-09-20', '09:00:00', 'Sala de Conferencias A', 2.0, 30, 11),
  ('Seguridad Eléctrica', 'Capacitación sobre cómo prevenir accidentes eléctricos y trabajar de manera segura con electricidad.', '2023-09-25', '14:30:00', 'Salón de Eventos B', 1.5, 25, 12),
  ('Prevención de Riesgos en la Construcción', 'Capacitación enfocada en los riesgos específicos de la industria de la construcción y las medidas de prevención.', '2023-09-30', '10:00:00', 'Sala de Reuniones C', 3.0, 40, 13),
  ('Higiene y Seguridad Alimentaria', 'Capacitación sobre prácticas seguras de manipulación de alimentos y prevención de contaminación.', '2023-10-05', '15:30:00', 'Salón de Conferencias D', 2.0, 20, 14),
  ('Prevención de Riesgos en Laboratorios', 'Capacitación para trabajar de manera segura en laboratorios y evitar exposición a sustancias peligrosas.', '2023-10-10', '11:00:00', 'Sala de Capacitación E', 2.5, 35, 15),
  ('Protección contra Incendios Forestales', 'Capacitación para prevenir y combatir incendios forestales y proteger el medio ambiente.', '2023-10-15', '08:30:00', 'Salón de Eventos F', 1.0, 15, 16),
  ('Manejo Seguro de Productos Químicos', 'Capacitación sobre el correcto manejo y almacenamiento de productos químicos peligrosos.', '2023-10-20', '13:00:00', 'Sala de Reuniones G', 2.0, 25, 17),
  ('Prevención de Riesgos en Trabajos en Altura', 'Capacitación sobre las medidas de seguridad para trabajos en altura y uso de equipos adecuados.', '2023-10-25', '09:30:00', 'Salón de Conferencias H', 3.5, 40, 18),
  ('Manejo de Emergencias y Evacuación', 'Capacitación para actuar en situaciones de emergencia, evacuación y primeros auxilios.', '2023-10-30', '14:00:00', 'Sala de Capacitación I', 2.5, 30, 19),
  ('Seguridad Vial', 'Capacitación sobre prevención de accidentes de tránsito y seguridad al conducir.', '2023-11-05', '10:30:00', 'Salón de Eventos J', 2.0, 20, 20);

select * from capacitacion;