INSERT INTO chequeo (visita_id, detalle, estado)
VALUES
  (1, 'Revisar estado de extintores', 'Completado'),
  (2, 'Verificar señalización de salidas de emergencia', 'Completado'),
  (3, 'Inspeccionar equipos de protección personal', 'Completado'),
  (4, 'Revisar condiciones de seguridad en áreas de trabajo', 'Pendiente'),
  (5, 'Evaluar riesgos en el lugar de trabajo', 'Pendiente'),
  (6, 'Verificar cumplimiento de medidas de prevención', 'Pendiente'),
  (7, 'Capacitar al personal en el uso de equipos', 'Completado'),
  (8, 'Evaluar condiciones de iluminación en las instalaciones', 'Completado'),
  (9, 'Revisar plan de emergencia y evacuación', 'Completado'),
  (10, 'Inspeccionar botiquín de primeros auxilios', 'Completado'),
  (11, 'Realizar inspección de maquinaria', 'Pendiente'),
  (12, 'Evaluar condiciones de ventilación en espacios de trabajo', 'Pendiente'),
  (13, 'Verificar cumplimiento de normas de seguridad', 'Completado'),
  (14, 'Revisar estado de protecciones en equipos', 'Completado'),
  (15, 'Capacitar al personal en medidas de prevención de incendios', 'Completado'),
  (16, 'Evaluar condiciones de almacenamiento de materiales peligrosos', 'Completado'),
  (17, 'Realizar simulacro de evacuación', 'Pendiente'),
  (18, 'Verificar estado de extintores y alarmas', 'Pendiente'),
  (19, 'Revisar registros de capacitaciones anteriores', 'Completado'),
  (20, 'Inspeccionar áreas de trabajo para detectar posibles riesgos', 'Completado');

select * from chequeo;