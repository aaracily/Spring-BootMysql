select * from cliente;
insert into cliente (rut, nombre, apellido, correo, telefono, afp, sistema_salud, direccion, comuna, edad, usuario_id)
values ("1-1","cliente1","Contreras","magda@mimail.com","56989767689","vital","fonasa","avenida pardo 1800","olmue",45,1),
("2-2","cliente2","Blanco","blanco@mimail.com","56970709090","ProHabitad","isapre","calle los pinos 300","olmue",37,2);