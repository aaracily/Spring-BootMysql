INSERT INTO usuario (rol, username, password)
VALUES
    ('Administrativo', 'usuario1', '123456'),
    ('Administrativo', 'usuario2', '123456'),
    ('Administrativo', 'usuario3', '123456'),
    ('Administrativo', 'usuario4', '123456'),
    ('Administrativo', 'usuario5', '123456'),
    ('Administrativo', 'usuario6', '123456'),
    ('Administrativo', 'usuario7', '123456'),
    ('Cliente', 'usuario8', '123456'),
    ('Cliente', 'usuario9', '123456'),
    ('Cliente', 'usuario10', '123456'),
    ('Cliente', 'usuario11', '123456'),
    ('Cliente', 'usuario12', '123456'),
    ('Cliente', 'usuario13', '123456'),
    ('Cliente', 'usuario14', '123456'),
    ('Profesional', 'usuario15', '123456'),
    ('Profesional', 'usuario16', '123456'),
    ('Profesional', 'usuario17', '123456'),
    ('Profesional', 'usuario18', '123456'),
    ('Profesional', 'usuario19', '123456'),
    ('Profesional', 'usuario20', '123456');

select * from usuario;