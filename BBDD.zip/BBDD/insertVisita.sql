INSERT INTO visita (cliente_id, fecha, hora, lugar, realizado, detalle, profesional_id)
VALUES
  (1, '2023-08-01', '09:00:00', 'Oficina del cliente A', true, 'Visita para revisión de instalaciones', 1),
  (2, '2023-08-05', '14:30:00', 'Planta de producción cliente B', true, 'Visita de seguimiento de seguridad', 2),
  (3, '2023-08-10', '10:00:00', 'Sede cliente C', false, 'Visita programada para la próxima semana', 3),
  (4, '2023-08-15', '15:30:00', 'Oficina del cliente D', true, 'Visita de capacitación en seguridad laboral', 4),
  (5, '2023-08-20', '11:00:00', 'Centro de operaciones cliente E', true, 'Visita para revisar protocolos de emergencia', 5),
  (6, '2023-08-25', '08:30:00', 'Sede cliente F', false, 'Visita pendiente por confirmar fecha', 6),
  (7, '2023-08-30', '13:00:00', 'Planta de producción cliente G', true, 'Visita de inspección de equipos', 7),
  (8, '2023-09-05', '09:30:00', 'Oficina del cliente H', true, 'Visita para asesorar en medidas de prevención', 8),
  (9, '2023-09-10', '14:00:00', 'Centro de operaciones cliente I', false, 'Visita reprogramada para el próximo mes', 9),
  (10, '2023-09-15', '10:30:00', 'Sede cliente J', true, 'Visita de seguimiento en implementación de medidas', 10),
  (11, '2023-09-20', '09:00:00', 'Oficina del cliente K', true, 'Visita para revisión de instalaciones', 11),
  (12, '2023-09-25', '14:30:00', 'Planta de producción cliente L', true, 'Visita de seguimiento de seguridad', 12),
  (13, '2023-09-30', '10:00:00', 'Sede cliente M', false, 'Visita programada para la próxima semana', 13),
  (14, '2023-10-05', '15:30:00', 'Oficina del cliente N', true, 'Visita de capacitación en seguridad laboral', 14),
  (15, '2023-10-10', '11:00:00', 'Centro de operaciones cliente O', true, 'Visita para revisar protocolos de emergencia', 15),
  (16, '2023-10-15', '08:30:00', 'Sede cliente P', false, 'Visita pendiente por confirmar fecha', 16),
  (17, '2023-10-20', '13:00:00', 'Planta de producción cliente Q', true, 'Visita de inspección de equipos', 17),
  (18, '2023-10-25', '09:30:00', 'Oficina del cliente R', true, 'Visita para asesorar en medidas de prevención', 18),
  (19, '2023-10-30', '14:00:00', 'Centro de operaciones cliente S', false, 'Visita reprogramada para el próximo mes', 19),
  (20, '2023-11-05', '10:30:00', 'Sede cliente T', true, 'Visita de seguimiento en implementación de medidas', 20);

select * from visita;