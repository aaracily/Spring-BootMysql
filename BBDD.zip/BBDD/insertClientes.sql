INSERT INTO cliente (rut, nombre, apellido, correo, telefono, afp, sistema_salud, direccion, comuna, edad, usuario_id)
VALUES
  ('12345678-9', 'Juan', 'Pérez', 'juan.perez@example.com', '+56 9 1111 1111', 'AFP Provida', 'isapre', 'Calle 1', 'Santiago', 35, 1),
  ('98765432-1', 'María', 'López', 'maria.lopez@example.com', '+56 9 2222 2222', 'AFP Habitat', 'fonasa', 'Avenida 2', 'Valparaíso', 40, 2),
  ('45678912-3', 'Carlos', 'González', 'carlos.gonzalez@example.com', '+56 9 3333 3333', 'AFP Cuprum', 'isapre', 'Calle 3', 'Concepción', 28, 3),
  ('32198765-4', 'Laura', 'Rodríguez', 'laura.rodriguez@example.com', '+56 9 4444 4444', 'AFP Capital', 'isapre', 'Avenida 4', 'Antofagasta', 45, 4),
  ('65432198-5', 'Pedro', 'Hernández', 'pedro.hernandez@example.com', '+56 9 5555 5555', 'AFP Modelo', 'fonasa', 'Calle 5', 'Iquique', 32, 5),
  ('78912345-6', 'Ana', 'Gómez', 'ana.gomez@example.com', '+56 9 6666 6666', 'AFP Provida', 'isapre', 'Avenida 6', 'Viña del Mar', 50, 6),
  ('23456789-0', 'Andrés', 'Silva', 'andres.silva@example.com', '+56 9 7777 7777', 'AFP Habitat', 'fonasa', 'Calle 7', 'La Serena', 29, 7),
  ('56789012-3', 'Camila', 'Fernández', 'camila.fernandez@example.com', '+56 9 8888 8888', 'AFP Cuprum', 'isapre', 'Avenida 8', 'Talca', 48, 8),
  ('89012345-6', 'José', 'Molina', 'jose.molina@example.com', '+56 9 9999 9999', 'AFP Capital', 'isapre', 'Calle 9', 'Temuco', 26, 9),
  ('98765432-1', 'Paula', 'Ruiz', 'paula.ruiz@example.com', '+56 9 1010 1010', 'AFP Modelo', 'fonasa', 'Avenida 10', 'Punta Arenas', 36, 10),
  ('54321098-7', 'Fernanda', 'Ramírez', 'fernanda.ramirez@example.com', '+56 9 1212 1212', 'AFP Provida', 'isapre', 'Calle 11', 'Puerto Montt', 42, 11),
  ('67890123-4', 'Ricardo', 'Ortega', 'ricardo.ortega@example.com', '+56 9 1313 1313', 'AFP Habitat', 'fonasa', 'Avenida 12', 'Rancagua', 33, 12),
  ('43210987-6', 'Sofía', 'Mendoza', 'sofia.mendoza@example.com', '+56 9 1414 1414', 'AFP Cuprum', 'isapre', 'Calle 13', 'Coquimbo', 27, 13),
  ('78901234-5', 'Mateo', 'Herrera', 'mateo.herrera@example.com', '+56 9 1515 1515', 'AFP Capital', 'isapre', 'Avenida 14', 'Valdivia', 31, 14),
  ('34567890-1', 'Valeria', 'Castro', 'valeria.castro@example.com', '+56 9 1616 1616', 'AFP Modelo', 'fonasa', 'Calle 15', 'Arica', 29, 15),
  ('23456789-0', 'Javier', 'Guzmán', 'javier.guzman@example.com', '+56 9 1717 1717', 'AFP Provida', 'isapre', 'Avenida 16', 'Copiapó', 49, 16),
  ('56789012-3', 'Isabel', 'Paredes', 'isabel.paredes@example.com', '+56 9 1818 1818', 'AFP Habitat', 'fonasa', 'Calle 17', 'Osorno', 30, 17),
  ('89012345-6', 'Martina', 'Molina', 'martina.molina@example.com', '+56 9 1919 1919', 'AFP Cuprum', 'isapre', 'Avenida 18', 'Quillota', 46, 18),
  ('98765432-1', 'Gabriel', 'Valenzuela', 'gabriel.valenzuela@example.com', '+56 9 2020 2020', 'AFP Capital', 'isapre', 'Calle 19', 'Los Ángeles', 34, 19),
  ('87654321-0', 'Renata', 'Soto', 'renata.soto@example.com', '+56 9 2121 2121', 'AFP Modelo', 'fonasa', 'Avenida 20', 'Chillán', 39, 20);

select * from cliente;