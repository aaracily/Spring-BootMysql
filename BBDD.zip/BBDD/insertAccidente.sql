INSERT INTO accidente (cliente_id, fecha_accidente, detalle)
VALUES
  (1, '2023-08-01', 'Accidente laboral: resbalón en el área de producción.'),
  (2, '2023-08-05', 'Accidente de tránsito: colisión de vehículos de la empresa.'),
  (3, '2023-08-10', 'Accidente en obra de construcción: caída de altura.'),
  (4, '2023-08-15', 'Accidente en laboratorio: exposición a sustancia química.'),
  (5, '2023-08-20', 'Accidente en oficina: golpe con equipo de trabajo.'),
  (6, '2023-08-25', 'Accidente de tránsito: atropello en área de estacionamiento.'),
  (7, '2023-08-30', 'Accidente en planta industrial: atrapamiento en maquinaria.'),
  (8, '2023-09-05', 'Accidente laboral: cortes en manos por herramientas no adecuadas.'),
  (9, '2023-09-10', 'Accidente en almacén: caída de objetos desde estantería.'),
  (10, '2023-09-15', 'Accidente en área de trabajo: quemadura por derrame de líquido.'),
  (11, '2023-09-20', 'Accidente de tránsito: choque de vehículo de la empresa.'),
  (12, '2023-09-25', 'Accidente en construcción: golpe por objetos en movimiento.'),
  (13, '2023-09-30', 'Accidente en laboratorio: corte con vidrio roto.'),
  (14, '2023-10-05', 'Accidente en oficina: caída por superficie resbaladiza.'),
  (15, '2023-10-10', 'Accidente en planta industrial: quemadura por manipulación de equipo.'),
  (16, '2023-10-15', 'Accidente laboral: lesión por esfuerzo repetitivo.'),
  (17, '2023-10-20', 'Accidente en almacén: caída de estantería por sobrecarga.'),
  (18, '2023-10-25', 'Accidente en área de trabajo: golpe con objeto contundente.'),
  (19, '2023-10-30', 'Accidente de tránsito: atropello en área de estacionamiento.'),
  (20, '2023-11-05', 'Accidente en construcción: caída de altura desde andamio.');

select * from accidente;