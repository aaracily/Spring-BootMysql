INSERT INTO asistente (capacitacion_id, usuario_id)
VALUES
  (1, 1),
  (1, 2),
  (1, 3),
  (1, 4),
  (1, 5),
  (2, 6),
  (2, 7),
  (2, 8),
  (3, 9),
  (3, 10),
  (4, 11),
  (4, 12),
  (5, 13),
  (6, 14),
  (6, 15),
  (7, 16),
  (8, 17),
  (9, 18),
  (10, 19),
  (11, 20);
  
select * from asistente;