INSERT INTO profesional (run, nombre, apellido, correo, telefono, cargo, usuario_id)
VALUES
  ('12345678-9', 'Ana', 'García', 'ana.garcia@example.com', '+56 9 1111 1111', 'Gerente de Ventas', 1),
  ('98765432-1', 'Carlos', 'López', 'carlos.lopez@example.com', '+56 9 2222 2222', 'Ingeniero de Software', 2),
  ('45678912-3', 'Laura', 'Martínez', 'laura.martinez@example.com', '+56 9 3333 3333', 'Analista Financiero', 3),
  ('32198765-4', 'Martín', 'Rodríguez', 'martin.rodriguez@example.com', '+56 9 4444 4444', 'Arquitecto', 4),
  ('65432198-5', 'Valentina', 'Hernández', 'valentina.hernandez@example.com', '+56 9 5555 5555', 'Diseñadora Gráfica', 5),
  ('78912345-6', 'Alejandro', 'Gómez', 'alejandro.gomez@example.com', '+56 9 6666 6666', 'Gerente de Recursos Humanos', 6),
  ('23456789-0', 'Sofía', 'Silva', 'sofia.silva@example.com', '+56 9 7777 7777', 'Contador', 7),
  ('56789012-3', 'Diego', 'Ramírez', 'diego.ramirez@example.com', '+56 9 8888 8888', 'Marketing Manager', 8),
  ('89012345-6', 'Isabella', 'Vargas', 'isabella.vargas@example.com', '+56 9 9999 9999', 'Especialista en Recursos Humanos', 9),
  ('98765432-1', 'Julián', 'López', 'julian.lopez@example.com', '+56 9 1010 1010', 'Ingeniero de Proyectos', 10),
  ('87654321-0', 'Gabriela', 'Torres', 'gabriela.torres@example.com', '+56 9 1212 1212', 'Analista de Marketing', 11),
  ('54321098-7', 'Andrés', 'Pérez', 'andres.perez@example.com', '+56 9 1313 1313', 'Abogado', 12),
  ('67890123-4', 'Natalia', 'González', 'natalia.gonzalez@example.com', '+56 9 1414 1414', 'Ingeniero Civil', 13),
  ('43210987-6', 'Sebastián', 'Mendoza', 'sebastian.mendoza@example.com', '+56 9 1515 1515', 'Analista de Sistemas', 14),
  ('78901234-5', 'Mariana', 'Herrera', 'mariana.herrera@example.com', '+56 9 1616 1616', 'Jefe de Producción', 15),
  ('34567890-1', 'Daniel', 'Castro', 'daniel.castro@example.com', '+56 9 1717 1717', 'Diseñador Industrial', 16),
  ('23456789-0', 'Camila', 'Guzmán', 'camila.guzman@example.com', '+56 9 1818 1818', 'Gerente de Operaciones', 17),
  ('56789012-3', 'Felipe', 'Ortega', 'felipe.ortega@example.com', '+56 9 1919 1919', 'Desarrollador Web', 18),
  ('89012345-6', 'Victoria', 'Paredes', 'victoria.paredes@example.com', '+56 9 2020 2020', 'Especialista en Recursos Humanos', 19),
  ('98765432-1', 'Manuel', 'Valenzuela', 'manuel.valenzuela@example.com', '+56 9 2121 2121', 'Analista de Finanzas', 20);

select * from profesional;